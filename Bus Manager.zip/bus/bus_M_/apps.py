from django.apps import AppConfig


class BusMConfig(AppConfig):
    name = 'bus_M_'
